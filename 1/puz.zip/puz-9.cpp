#include <string>
#include <iostream>
#include <cstdio>

// Write code here so that the contents of the main function prints PASS and FAIL.

int main()
{
    // Write code here so that the code below prints PASS and FAIL.

    A::A.A->A="PASS";
    A(A::A.A->A); // This should print PASS
    A::A.A->A="FAIL";
    A(A::A.A->A); // This should print FAIL

    return 0;
}



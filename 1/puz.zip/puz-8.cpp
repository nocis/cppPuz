#include <string>
#include <iostream>
#include <cstdio>

int main()
{
    // Write code here to print PASS.  You are not allowed to use the semicolon character.

    return 0;
}



#include <cstdio>

template<class R,class S,class T>
void foo(R* r, S* s, T* t)
{
    s = r;
    t = s;
    if(r != t) puts("PASS");
}

int main()
{
    // Call foo so that it prints PASS.

    return 0;
}


